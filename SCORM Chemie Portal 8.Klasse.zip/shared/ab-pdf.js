/* ============================================================
   AB-PDF — generische PDF-Export-Funktionen
   ============================================================
   Aufruf:
     ABPdf.export({
       titel: 'Reibungselektrizität',
       untertitel: 'Was passiert mit den Atomen?',
       fach: 'Chemie',
       klasse: '8c',
       datum: '30. April 2026',
       dateiname: 'Reibungselektrizitaet_Klasse_8c.pdf',
       inhalt: (h) => {
         h.section('Der Versuch');
         h.paragraph('Aufbau: ein Luftballon ...');
         h.simSnapshot(document.getElementById('sim-x'), 'Abb. 1', 'Beschreibung');
         h.aufgabe(1, 'Beschreibe', 'deine Beobachtungen ...');
         h.canvasFeld('a1');
         h.merke('Atome bestehen aus ...');
       }
     });
*/
(function() {
'use strict';

window.ABPdf = {
  async export(opts) {
    const overlay = document.getElementById('overlay');
    const overlayText = document.getElementById('overlay-text');
    if (overlay) overlay.classList.add('aktiv');
    if (overlayText) overlayText.textContent = 'PDF wird erstellt …';
    await new Promise(r => setTimeout(r, 50));

    try {
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF({ unit: 'mm', format: 'a4' });

      const PAGE_W = 210, PAGE_H = 297;
      const MARGIN_L = 18, MARGIN_R = 18, MARGIN_T = 22, MARGIN_B = 18;
      const CONTENT_W = PAGE_W - MARGIN_L - MARGIN_R;

      const COL_DARK = [26, 58, 92];
      const COL_CYAN = [0, 176, 240];
      const COL_CYAN_DARK = [0, 128, 176];
      const COL_TEXT = [45, 42, 38];
      const COL_GREY = [120, 120, 120];
      const COL_LINE = [216, 216, 216];
      const COL_HEFT = [181, 199, 216];

      let y = MARGIN_T;
      let pageNum = 1;

      function setFill(c) { doc.setFillColor(c[0], c[1], c[2]); }
      function setText(c) { doc.setTextColor(c[0], c[1], c[2]); }
      function setDraw(c) { doc.setDrawColor(c[0], c[1], c[2]); }

      function ensureSpace(needed) {
        if (y + needed <= PAGE_H - MARGIN_B - 14) return;
        drawFooter();
        doc.addPage();
        pageNum++;
        y = MARGIN_T;
        drawTopBar();
      }

      function drawTopBar() {
        setFill(COL_CYAN);
        doc.rect(0, 0, PAGE_W, 4, 'F');
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        setText(COL_GREY);
        doc.text(`${opts.titel} · Klasse ${opts.klasse}`, MARGIN_L, 14);
        doc.text(opts.datum, PAGE_W - MARGIN_R, 14, { align: 'right' });
        y = 22;
      }

      function drawFooter() {
        const fy = PAGE_H - 12;
        setDraw(COL_LINE);
        doc.setLineWidth(0.2);
        doc.line(MARGIN_L, fy, PAGE_W - MARGIN_R, fy);
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        setText(COL_GREY);
        doc.text(`Klasse ${opts.klasse} · ${opts.titel}`, MARGIN_L, fy + 5);
        doc.text(`Seite ${pageNum}`, PAGE_W - MARGIN_R, fy + 5, { align: 'right' });
      }

      function drawTitleHeader() {
        setFill(COL_CYAN);
        doc.rect(0, 0, PAGE_W, 6, 'F');

        const badgeX = MARGIN_L, badgeY = 14;
        const badgeW = 24, badgeH = 9;
        setFill(COL_CYAN);
        doc.roundedRect(badgeX, badgeY, badgeW, badgeH, 1.5, 1.5, 'F');
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(11);
        setText([255,255,255]);
        doc.text(`Klasse ${opts.klasse}`, badgeX + badgeW/2, badgeY + 6.2, { align: 'center' });

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        setText(COL_GREY);
        doc.text(opts.datum, PAGE_W - MARGIN_R, badgeY + 6.2, { align: 'right' });

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(22);
        setText(COL_DARK);
        const titleLines = doc.splitTextToSize(opts.titel, CONTENT_W);
        doc.text(titleLines, MARGIN_L, badgeY + 22);

        if (opts.untertitel) {
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(13);
          setText(COL_GREY);
          doc.text(opts.untertitel, MARGIN_L, badgeY + 22 + (titleLines.length * 8));
        }

        setDraw(COL_LINE);
        doc.setLineWidth(0.3);
        const lineY = badgeY + 22 + ((titleLines.length) * 8) + (opts.untertitel ? 5 : 5);
        doc.line(MARGIN_L, lineY, PAGE_W - MARGIN_R, lineY);

        y = lineY + 8;
      }

      // ===== HELPERS für Inhalts-Aufruf =====
      const h = {
        section(titel) {
          ensureSpace(11);
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(13);
          setText(COL_DARK);
          doc.text(titel, MARGIN_L, y);
          y += 2;
          setDraw(COL_CYAN);
          doc.setLineWidth(0.5);
          doc.line(MARGIN_L, y, MARGIN_L + 30, y);
          y += 5;
        },
        paragraph(text, o = {}) {
          if (o.italic) doc.setFont('helvetica', 'italic');
          else doc.setFont('helvetica', 'normal');
          doc.setFontSize(10.5);
          setText(o.muted ? COL_GREY : COL_TEXT);
          const lines = doc.splitTextToSize(text, CONTENT_W);
          ensureSpace(lines.length * 5 + 3);
          doc.text(lines, MARGIN_L, y);
          y += lines.length * 5 + 3;
        },
        aufgabe(nr, op, rest) {
          const praefix = `${nr ? nr + '. ' : ''}${op} `;
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(10.5);
          const praefixW = doc.getTextWidth(praefix);

          doc.setFont('helvetica', 'normal');
          const ersteZeileW = CONTENT_W - praefixW;
          const woerter = rest.split(' ');
          let ersteZeileText = '';
          for (const w of woerter) {
            const probe = ersteZeileText ? ersteZeileText + ' ' + w : w;
            if (doc.getTextWidth(probe) > ersteZeileW) break;
            ersteZeileText = probe;
          }
          const restAbZweite = rest.substring(ersteZeileText.length).trim();
          const folgeZeilen = restAbZweite ? doc.splitTextToSize(restAbZweite, CONTENT_W) : [];

          const gesamtZeilen = 1 + folgeZeilen.length;
          const textH = gesamtZeilen * 5.2;
          ensureSpace(textH + 3);

          const startY = y + 4;
          doc.setFont('helvetica', 'bold');
          setText(COL_TEXT);
          doc.text(praefix, MARGIN_L, startY);
          doc.setFont('helvetica', 'normal');
          doc.text(ersteZeileText, MARGIN_L + praefixW, startY);
          if (folgeZeilen.length > 0) {
            doc.text(folgeZeilen, MARGIN_L, startY + 5.2);
          }
          y += textH + 2;
        },
        canvasFeld(canvasId) {
          const state = window.ABEngine.getCanvasState(canvasId);
          if (!state) return;
          const hasContent = state.paths.length > 0;
          const canvas = state.canvas;
          const aspect = canvas.height / canvas.width;
          const imgW = CONTENT_W;
          const fullImgH = Math.max(28, imgW * aspect);

          const availH = (PAGE_H - MARGIN_B - 14) - y;
          if (fullImgH <= availH) {
            zeichneCanvasBlock(canvas, hasContent, MARGIN_L, y, imgW, fullImgH, 0, 1);
            y += fullImgH + 6;
            return;
          }
          if (availH < 25) {
            drawFooter();
            doc.addPage(); pageNum++; y = MARGIN_T; drawTopBar();
            zeichneCanvasBlock(canvas, hasContent, MARGIN_L, y, imgW, fullImgH, 0, 1);
            y += fullImgH + 6;
            return;
          }
          const ratio1 = availH / fullImgH;
          zeichneCanvasBlock(canvas, hasContent, MARGIN_L, y, imgW, availH, 0, ratio1);
          const restH = fullImgH - availH;
          drawFooter();
          doc.addPage(); pageNum++; y = MARGIN_T; drawTopBar();
          zeichneCanvasBlock(canvas, hasContent, MARGIN_L, y, imgW, restH, ratio1, 1 - ratio1);
          y += restH + 6;
        },
        simSnapshot(canvasEl, captionTitle, captionText) {
          if (!canvasEl) return;
          const aspect = canvasEl.height / canvasEl.width;
          const imgW = CONTENT_W * 0.86;
          const imgH = imgW * aspect;
          ensureSpace(imgH + 14);
          const xCenter = MARGIN_L + (CONTENT_W - imgW) / 2;

          setFill([245, 248, 251]);
          doc.rect(xCenter + 1, y + 1, imgW, imgH, 'F');
          setFill([255, 255, 255]);
          doc.rect(xCenter, y, imgW, imgH, 'F');
          try {
            doc.addImage(canvasEl.toDataURL('image/png'), 'PNG', xCenter, y, imgW, imgH);
          } catch(e) { console.warn('simSnapshot toDataURL failed', e); }
          setDraw(COL_LINE);
          doc.setLineWidth(0.4);
          doc.rect(xCenter, y, imgW, imgH);

          y += imgH + 3;
          doc.setFont('helvetica', 'bold');
          doc.setFontSize(8.5);
          setText(COL_CYAN_DARK);
          const tx = MARGIN_L + CONTENT_W / 2;
          doc.text(captionTitle, tx, y + 3, { align: 'center' });
          doc.setFont('helvetica', 'italic');
          setText(COL_GREY);
          const lines = doc.splitTextToSize(captionText, CONTENT_W * 0.9);
          doc.text(lines, tx, y + 7, { align: 'center' });
          y += 7 + lines.length * 4 + 5;
        },
        merke(text) {
          ensureSpace(20);
          const lines = doc.splitTextToSize(text, CONTENT_W - 8);
          const blockH = 8 + lines.length * 5;
          ensureSpace(blockH + 4);

          setFill([240, 250, 254]);
          doc.rect(MARGIN_L, y, CONTENT_W, blockH, 'F');
          setFill(COL_CYAN);
          doc.rect(MARGIN_L, y, 3, blockH, 'F');

          doc.setFont('helvetica', 'bold');
          doc.setFontSize(10.5);
          setText(COL_CYAN_DARK);
          doc.text('Merke', MARGIN_L + 6, y + 5);
          doc.setFont('helvetica', 'normal');
          setText(COL_TEXT);
          doc.text(lines, MARGIN_L + 6, y + 11);
          y += blockH + 6;
        },
        infoBox(text) {
          const lines = doc.splitTextToSize(text, CONTENT_W - 8);
          const blockH = 6 + lines.length * 5;
          ensureSpace(blockH + 4);
          setFill([255, 248, 225]);
          doc.rect(MARGIN_L, y, CONTENT_W, blockH, 'F');
          setFill([240, 180, 0]);
          doc.rect(MARGIN_L, y, 3, blockH, 'F');
          doc.setFont('helvetica', 'normal');
          doc.setFontSize(10);
          setText(COL_TEXT);
          doc.text(lines, MARGIN_L + 6, y + 5);
          y += blockH + 4;
        }
      };

      function zeichneCanvasBlock(canvas, hasContent, x, yPos, w, h, vRatioStart, vRatioPart) {
        setFill([252, 253, 254]);
        doc.rect(x, yPos, w, h, 'F');
        setDraw(COL_HEFT);
        doc.setLineWidth(0.15);
        const lineSpacing = 6;
        for (let yl = yPos + lineSpacing; yl < yPos + h - 1; yl += lineSpacing) {
          doc.line(x + 2, yl, x + w - 2, yl);
        }
        if (hasContent) {
          try {
            const srcY = Math.floor(canvas.height * vRatioStart);
            const srcH = Math.ceil(canvas.height * vRatioPart);
            const tmp = document.createElement('canvas');
            tmp.width = canvas.width;
            tmp.height = srcH;
            const tctx = tmp.getContext('2d');
            tctx.drawImage(canvas, 0, srcY, canvas.width, srcH, 0, 0, canvas.width, srcH);
            doc.addImage(tmp.toDataURL('image/png'), 'PNG', x, yPos, w, h);
          } catch(e) { console.warn('Canvas split fail', e); }
        }
        setDraw(COL_LINE);
        doc.setLineWidth(0.3);
        doc.rect(x, yPos, w, h);
      }

      // INHALT
      drawTitleHeader();
      if (overlayText) overlayText.textContent = 'Inhalt wird erzeugt …';
      await new Promise(r => setTimeout(r, 30));
      opts.inhalt(h);
      drawFooter();

      if (overlayText) overlayText.textContent = 'PDF wird gespeichert …';
      await new Promise(r => setTimeout(r, 50));
      doc.save(opts.dateiname);
    } catch(err) {
      console.error(err);
      alert('Fehler beim PDF-Export: ' + err.message);
    } finally {
      if (overlay) overlay.classList.remove('aktiv');
    }
  }
};

})();
