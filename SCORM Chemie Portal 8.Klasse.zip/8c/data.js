// Inhalts-Manifest für Klasse 8c
// Pflege diese Datei, um neue ABs / Übungen hinzuzufügen.
window.PORTAL_DATA = {
  "klasse": "8c",
  "schuljahr": "2025/26",

  "arbeitsblaetter": [
    {
      "titel": "Reibungselektrizität – Was passiert mit den Atomen?",
      "datei": "ab/reibungselektrizitaet.html",
      "lernbereich": "LB 4",
      "thema": "Atombau",
      "datum": "05.05.2026",
      "beschreibung": "Einstieg in die Bausteine der Atome – vom Phänomen der Reibungselektrizität zu Thomsons Entdeckung des Elektrons.",
      "id": "ab_reibungselektrizitaet"
    }
  ],

  "uebungen": [
    {
      "titel": "Stöchiometrie-Trainer",
      "datei": "uebungen/stoechiometrietrainer.html",
      "lernbereich": "LB 3",
      "thema": "Chemisches Rechnen",
      "beschreibung": "Übe Stoffmenge, Teilchenzahl, molare Masse und die Beziehung m = n · M. Drei Schwierigkeitsstufen mit Hinweisen.",
      "level": "3 Stufen",
      "id": "uebung_stoechiometrie"
    }
  ]
};
